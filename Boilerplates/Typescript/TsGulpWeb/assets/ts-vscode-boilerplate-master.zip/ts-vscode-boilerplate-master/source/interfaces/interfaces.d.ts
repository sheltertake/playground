/// <reference path="./greeter.d.ts" />
