interface GreeterInterface {
    greeting: string;
    greet: () => string;
}
